# Machine Learning Projects

This repository contains machine Learning Projects on various datasets.
